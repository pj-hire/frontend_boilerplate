function helloWorld1() {
  console.log('Hello World from script 1');
}

helloWorld1();
