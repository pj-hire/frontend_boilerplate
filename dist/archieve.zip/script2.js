function helloWorld2() {
  console.log('Hello World from script 2');
}

helloWorld2();
